from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    event,
)
from sqlalchemy.orm import relationship
from datetime import datetime
from app.db.session import Base

class OptionChainSnapshot(Base):
    __tablename__ = "option_chain_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    instrument_type = Column(String(10), default="INDEX")
    expiry_date = Column(String(20), index=True)
    spot_price = Column(Float)
    provider = Column(String(20))
    collection_status = Column(String(20))
    collection_duration_ms = Column(Integer)

    # Relationships
    strikes = relationship("OptionChainStrike", back_populates="snapshot", cascade="all, delete-orphan")


class OptionChainStrike(Base):
    __tablename__ = "option_chain_strikes"

    id = Column(Integer, primary_key=True, index=True)
    snapshot_id = Column(Integer, ForeignKey("option_chain_snapshots.id", ondelete="CASCADE"), index=True)
    strike = Column(Float, index=True)
    
    # Call options data
    call_oi = Column(Integer, default=0)
    call_change_oi = Column(Integer, default=0)
    call_volume = Column(Integer, default=0)
    call_iv = Column(Float, default=0.0)
    call_ltp = Column(Float, default=0.0)
    call_bid = Column(Float, default=0.0)
    call_ask = Column(Float, default=0.0)
    call_delta = Column(Float, default=0.0)
    call_gamma = Column(Float, default=0.0)
    call_theta = Column(Float, default=0.0)
    call_vega = Column(Float, default=0.0)
    
    # Put options data
    put_oi = Column(Integer, default=0)
    put_change_oi = Column(Integer, default=0)
    put_volume = Column(Integer, default=0)
    put_iv = Column(Float, default=0.0)
    put_ltp = Column(Float, default=0.0)
    put_bid = Column(Float, default=0.0)
    put_ask = Column(Float, default=0.0)
    put_delta = Column(Float, default=0.0)
    put_gamma = Column(Float, default=0.0)
    put_theta = Column(Float, default=0.0)
    put_vega = Column(Float, default=0.0)

    # Relationship
    snapshot = relationship("OptionChainSnapshot", back_populates="strikes")


class AnalyticsSnapshot(Base):
    __tablename__ = "analytics_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    instrument_type = Column(String(10), default="INDEX")
    expiry_date = Column(String(20), index=True)
    source_snapshot_id = Column(Integer, ForeignKey("option_chain_snapshots.id", ondelete="SET NULL"), nullable=True)
    current_spot = Column(Float)
    pcr = Column(Float)
    market_state = Column(String(30))
    strength = Column(String(10)) # LOW, MEDIUM, HIGH
    iv_change = Column(Float)
    support = Column(Float)
    secondary_support = Column(Float, nullable=True)
    resistance = Column(Float)
    secondary_resistance = Column(Float, nullable=True)
    distance_to_support = Column(Float)
    distance_to_resistance = Column(Float)
    support_strength = Column(String(10)) # LOW, MEDIUM, HIGH
    resistance_strength = Column(String(10)) # LOW, MEDIUM, HIGH


class GeneratedInsight(Base):
    __tablename__ = "generated_insights"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    expiry_date = Column(String(20), index=True, nullable=True)
    category = Column(String(30)) # BUILDUP, VOLATILITY, etc.
    insight_text = Column(String(255))
    confidence_level = Column(String(10)) # LOW, MEDIUM, HIGH
    rule_version = Column(String(10), default="v1.0")


class RawProviderResponse(Base):
    __tablename__ = "raw_provider_responses"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    provider = Column(String(20))
    symbol = Column(String(20), index=True)
    payload_json = Column(Text)


class OptionChainSnapshot5m(Base):
    __tablename__ = "aggregated_5m_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    instrument_type = Column(String(10), default="INDEX")
    expiry_date = Column(String(20), index=True)
    spot_price = Column(Float)
    provider = Column(String(20))
    collection_status = Column(String(20))
    collection_duration_ms = Column(Integer)

    # Relationships
    strikes = relationship("OptionChainStrike5m", back_populates="snapshot", cascade="all, delete-orphan")


class OptionChainStrike5m(Base):
    __tablename__ = "aggregated_5m_strikes"

    id = Column(Integer, primary_key=True, index=True)
    snapshot_id = Column(Integer, ForeignKey("aggregated_5m_snapshots.id", ondelete="CASCADE"), index=True)
    strike = Column(Float, index=True)
    
    # Call options data
    call_oi = Column(Integer, default=0)
    call_change_oi = Column(Integer, default=0)
    call_volume = Column(Integer, default=0)
    call_iv = Column(Float, default=0.0)
    call_ltp = Column(Float, default=0.0)
    call_bid = Column(Float, default=0.0)
    call_ask = Column(Float, default=0.0)
    call_delta = Column(Float, default=0.0)
    call_gamma = Column(Float, default=0.0)
    call_theta = Column(Float, default=0.0)
    call_vega = Column(Float, default=0.0)
    
    # Put options data
    put_oi = Column(Integer, default=0)
    put_change_oi = Column(Integer, default=0)
    put_volume = Column(Integer, default=0)
    put_iv = Column(Float, default=0.0)
    put_ltp = Column(Float, default=0.0)
    put_bid = Column(Float, default=0.0)
    put_ask = Column(Float, default=0.0)
    put_delta = Column(Float, default=0.0)
    put_gamma = Column(Float, default=0.0)
    put_theta = Column(Float, default=0.0)
    put_vega = Column(Float, default=0.0)

    # Relationship
    snapshot = relationship("OptionChainSnapshot5m", back_populates="strikes")


class AnalyticsSnapshot5m(Base):
    __tablename__ = "analytics_snapshots_5m"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    instrument_type = Column(String(10), default="INDEX")
    expiry_date = Column(String(20), index=True)
    source_snapshot_id = Column(Integer, ForeignKey("aggregated_5m_snapshots.id", ondelete="SET NULL"), nullable=True)
    current_spot = Column(Float)
    pcr = Column(Float)
    market_state = Column(String(30))
    strength = Column(String(10)) # LOW, MEDIUM, HIGH
    iv_change = Column(Float)
    support = Column(Float)
    secondary_support = Column(Float, nullable=True)
    resistance = Column(Float)
    secondary_resistance = Column(Float, nullable=True)
    distance_to_support = Column(Float)
    distance_to_resistance = Column(Float)
    support_strength = Column(String(10)) # LOW, MEDIUM, HIGH
    resistance_strength = Column(String(10)) # LOW, MEDIUM, HIGH


class OptionChainSnapshot15m(Base):
    __tablename__ = "aggregated_15m_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    instrument_type = Column(String(10), default="INDEX")
    expiry_date = Column(String(20), index=True)
    spot_price = Column(Float)
    provider = Column(String(20))
    collection_status = Column(String(20))
    collection_duration_ms = Column(Integer)

    # Relationships
    strikes = relationship("OptionChainStrike15m", back_populates="snapshot", cascade="all, delete-orphan")


class OptionChainStrike15m(Base):
    __tablename__ = "aggregated_15m_strikes"

    id = Column(Integer, primary_key=True, index=True)
    snapshot_id = Column(Integer, ForeignKey("aggregated_15m_snapshots.id", ondelete="CASCADE"), index=True)
    strike = Column(Float, index=True)
    
    # Call options data
    call_oi = Column(Integer, default=0)
    call_change_oi = Column(Integer, default=0)
    call_volume = Column(Integer, default=0)
    call_iv = Column(Float, default=0.0)
    call_ltp = Column(Float, default=0.0)
    call_bid = Column(Float, default=0.0)
    call_ask = Column(Float, default=0.0)
    call_delta = Column(Float, default=0.0)
    call_gamma = Column(Float, default=0.0)
    call_theta = Column(Float, default=0.0)
    call_vega = Column(Float, default=0.0)
    
    # Put options data
    put_oi = Column(Integer, default=0)
    put_change_oi = Column(Integer, default=0)
    put_volume = Column(Integer, default=0)
    put_iv = Column(Float, default=0.0)
    put_ltp = Column(Float, default=0.0)
    put_bid = Column(Float, default=0.0)
    put_ask = Column(Float, default=0.0)
    put_delta = Column(Float, default=0.0)
    put_gamma = Column(Float, default=0.0)
    put_theta = Column(Float, default=0.0)
    put_vega = Column(Float, default=0.0)

    # Relationship
    snapshot = relationship("OptionChainSnapshot15m", back_populates="strikes")


class AnalyticsSnapshot15m(Base):
    __tablename__ = "analytics_snapshots_15m"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    instrument_type = Column(String(10), default="INDEX")
    expiry_date = Column(String(20), index=True)
    source_snapshot_id = Column(Integer, ForeignKey("aggregated_15m_snapshots.id", ondelete="SET NULL"), nullable=True)
    current_spot = Column(Float)
    pcr = Column(Float)
    market_state = Column(String(30))
    strength = Column(String(10)) # LOW, MEDIUM, HIGH
    iv_change = Column(Float)
    support = Column(Float)
    secondary_support = Column(Float, nullable=True)
    resistance = Column(Float)
    secondary_resistance = Column(Float, nullable=True)
    distance_to_support = Column(Float)
    distance_to_resistance = Column(Float)
    support_strength = Column(String(10)) # LOW, MEDIUM, HIGH
    resistance_strength = Column(String(10)) # LOW, MEDIUM, HIGH


class InsightOutcome(Base):
    __tablename__ = "insight_outcomes"

    id = Column(Integer, primary_key=True, index=True)
    snapshot_id = Column(Integer, ForeignKey("option_chain_snapshots.id", ondelete="CASCADE"), index=True)
    generated_at = Column(DateTime, index=True)
    symbol = Column(String(20), index=True)
    market_state = Column(String(30))
    prediction_direction = Column(String(10)) # BULLISH, BEARISH, NEUTRAL
    spot_at_generation = Column(Float)
    spot_after_5m = Column(Float, nullable=True)
    spot_after_15m = Column(Float, nullable=True)
    spot_after_30m = Column(Float, nullable=True)
    spot_after_60m = Column(Float, nullable=True)
    movement_5m_pct = Column(Float, nullable=True)
    movement_15m_pct = Column(Float, nullable=True)
    movement_30m_pct = Column(Float, nullable=True)
    movement_60m_pct = Column(Float, nullable=True)
    movement_5m_points = Column(Float, nullable=True)
    movement_15m_points = Column(Float, nullable=True)
    movement_30m_points = Column(Float, nullable=True)
    movement_60m_points = Column(Float, nullable=True)
    # --- Sprint 7 MFE/MAE Excursion Fields ---
    max_favorable_move_60m = Column(Float, nullable=True)  # Points: max price move in prediction direction within 60m
    max_adverse_move_60m = Column(Float, nullable=True)    # Points: max price move against prediction within 60m
    time_to_mfe_minutes = Column(Integer, nullable=True)   # Minutes to reach MFE
    time_to_mae_minutes = Column(Integer, nullable=True)   # Minutes to reach MAE
    is_mock = Column(Boolean, default=False, index=True)   # Flag to identify seeded developer mock data
    
    status = Column(String(20), default="PENDING", index=True)


class SystemMetadata(Base):
    __tablename__ = "system_metadata"

    key = Column(String(100), primary_key=True, index=True)
    value = Column(Text)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class MLFeatureSnapshot(Base):
    __tablename__ = "ml_feature_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    market_date = Column(String(20), index=True)
    timeframe = Column(String(10), index=True) # 1m, 5m, 15m
    symbol = Column(String(20), index=True)
    expiry_date = Column(String(20), index=True)
    expiry_type = Column(String(10)) # WEEKLY, MONTHLY
    source_snapshot_id = Column(Integer, ForeignKey("option_chain_snapshots.id", ondelete="SET NULL"), nullable=True)

    # Temporal & Session Features
    days_to_expiry = Column(Integer)
    minutes_from_open = Column(Integer)
    minutes_to_close = Column(Integer)
    session_phase = Column(String(20)) # OPENING, MIDDAY, CLOSING
    day_type = Column(String(20)) # EXPIRY_DAY, PRE_EXPIRY, NORMAL, MONTHLY_EXPIRY

    # Data Integrity, Flags & Lag Monitoring
    data_quality_score = Column(Integer)
    snapshot_age_seconds = Column(Float)
    feature_flags = Column(Text) # JSON string representation
    feature_schema_version = Column(String(10), default="v1")
    source_table = Column(String(50), default="option_chain_snapshots", index=True)
    engine_version = Column(String(20), default="features-v2.0")
    dataset_version = Column(String(20), default="research-v1.0")

    # Options Sentiment Features
    pcr = Column(Float, nullable=True)
    pcr_velocity = Column(Float, nullable=True)
    oi_imbalance = Column(Float, nullable=True)
    average_iv = Column(Float, nullable=True)
    iv_change = Column(Float, nullable=True)
    total_call_oi = Column(Integer, default=0)
    total_put_oi = Column(Integer, default=0)
    call_change_oi = Column(Integer, default=0)
    put_change_oi = Column(Integer, default=0)

    # Levels & Boundary Features (Normalized)
    distance_to_s1 = Column(Float, nullable=True)
    distance_to_s2 = Column(Float, nullable=True)
    distance_to_r1 = Column(Float, nullable=True)
    distance_to_r2 = Column(Float, nullable=True)
    distance_to_s1_pct = Column(Float, nullable=True)
    distance_to_r1_pct = Column(Float, nullable=True)
    sr_compression = Column(Float, nullable=True)
    support_strength = Column(String(10), nullable=True)
    resistance_strength = Column(String(10), nullable=True)

    # Market State & Microstructure Features
    market_state = Column(String(30), nullable=True)
    market_state_id = Column(Integer, nullable=True) # 0=NEUTRAL, 1=LONG_BUILDUP, 2=SHORT_BUILDUP, 3=SHORT_COVERING, 4=LONG_UNWINDING
    strength = Column(String(10), nullable=True)
    strength_score = Column(Integer, nullable=True) # 1=LOW, 2=MEDIUM, 3=HIGH
    ema20 = Column(Float, nullable=True)
    ema50 = Column(Float, nullable=True)
    atr = Column(Float, nullable=True)
    regime_trend = Column(String(20), nullable=True) # UPTREND, DOWNTREND, RANGE
    order_flow = Column(Float, nullable=True)

    # Retrospective Target Labels
    return_15m_pct = Column(Float, nullable=True)
    return_30m_pct = Column(Float, nullable=True)
    return_60m_pct = Column(Float, nullable=True)
    return_15m_points = Column(Float, nullable=True)
    return_30m_points = Column(Float, nullable=True)
    return_60m_points = Column(Float, nullable=True)

    direction_15m = Column(String(10), nullable=True) # UP, DOWN, SIDEWAYS
    direction_30m = Column(String(10), nullable=True)
    direction_60m = Column(String(10), nullable=True)

    label_quality = Column(String(20), nullable=True) # FULL, PARTIAL, INCOMPLETE
    available_horizons = Column(Text, nullable=True) # JSON string representation, e.g. ["15m", "30m"]

    # Leakage Protection Flag
    label_ready_at = Column(DateTime, index=True)
    status = Column(String(20), default="PENDING", index=True)


class TradingSignal(Base):
    __tablename__ = "trading_signals"

    id = Column(Integer, primary_key=True, index=True)
    snapshot_id = Column(Integer, ForeignKey("option_chain_snapshots.id", ondelete="CASCADE"), index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    expiry_date = Column(String(20), index=True)
    spot_price = Column(Float)
    signal_type = Column(String(20))          # BUY_CALL, BUY_PUT, NO_TRADE
    suggested_strike = Column(String(20), nullable=True) # e.g. "24100 CE"
    strike_selection_reason = Column(String(30), nullable=True) # e.g. "ATM", "ATM+1", "Highest OI"
    
    # Confidence raw parameters (allows comparing across versions with different count of rules)
    matched_conditions = Column(Integer, default=0)
    total_conditions = Column(Integer, default=0)
    
    reasons = Column(Text)                    # JSON serialized boolean rule state dictionary: e.g. {"price_up": true, "pcr_up": false, ...}
    signal_inputs = Column(Text, nullable=True) # JSON serialized inputs snapshot: e.g. {"spot": 25230, "pcr": 1.12, ...}
    market_state = Column(String(30))         # Buildup state at signal generation
    signal_version = Column(String(10), default="v1", index=True) # Version tracking for signal engines (v1, v2, etc.)
    was_executed = Column(Boolean, default=False) # User executed this signal manually or not
    
    # Sprint 16 V2 additions
    bullish_score = Column(Float, default=0.0)
    bearish_score = Column(Float, default=0.0)
    decision_margin = Column(Float, default=0.0)
    confidence_ratio = Column(Float, default=0.0)
    dynamic_threshold = Column(Float, default=70.0)
    raw_signal = Column(String(20), default="NO_TRADE")
    volume_z_score = Column(Float, default=0.0)
    feature_version = Column(String(10), default="v2.0")
    data_quality_score = Column(Integer, default=100)
    top_contributors = Column(Text, nullable=True)  # JSON serialized list of top contributors
    lifecycle_state = Column(String(20), default="CREATED")  # CREATED, STRENGTHENED, WEAKENED, CANCELLED, EXECUTED
    expected_strength = Column(String(30), nullable=True)     # Weak Setup, Developing Setup, Almost Ready, Strong Signal, Exceptional Setup
    closest_failed_rule = Column(String(50), nullable=True)   # Name of rule that failed, e.g. "VWAP Confirmation"
    
    # Excursion & evaluation parameters
    spot_after_15m = Column(Float, nullable=True)
    spot_after_30m = Column(Float, nullable=True)
    spot_after_60m = Column(Float, nullable=True)
    
    move_15m_points = Column(Float, nullable=True)
    move_30m_points = Column(Float, nullable=True)
    move_60m_points = Column(Float, nullable=True)
    
    move_15m_pct = Column(Float, nullable=True)
    move_30m_pct = Column(Float, nullable=True)
    move_60m_pct = Column(Float, nullable=True)
    
    outcome_15m = Column(String(20), default="PENDING") # WIN, LOSS, FLAT, PENDING
    outcome_30m = Column(String(20), default="PENDING")
    outcome_60m = Column(String(20), default="PENDING")
    
    status = Column(String(20), default="PENDING", index=True) # PENDING, COMPLETED


class ManualTraderDecision(Base):
    __tablename__ = "manual_trader_decisions"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    expiry_date = Column(String(20), index=True)
    spot_price = Column(Float)
    decision_type = Column(String(20)) # BUY_CALL, BUY_PUT, STAY_OUT
    suggested_strike = Column(String(20), nullable=True) # e.g. "80500 CE"
    confidence_level = Column(String(10)) # LOW, MEDIUM, HIGH
    notes = Column(Text, nullable=True) # JSON structured notes: e.g. {"price_above_vwap": true, ...}
    matched_system_signal_id = Column(Integer, ForeignKey("trading_signals.id", ondelete="SET NULL"), nullable=True)
    was_executed = Column(Boolean, default=True)
    
    # Excursion & evaluation parameters
    spot_after_15m = Column(Float, nullable=True)
    spot_after_30m = Column(Float, nullable=True)
    spot_after_60m = Column(Float, nullable=True)
    
    move_15m_points = Column(Float, nullable=True)
    move_30m_points = Column(Float, nullable=True)
    move_60m_points = Column(Float, nullable=True)
    
    move_15m_pct = Column(Float, nullable=True)
    move_30m_pct = Column(Float, nullable=True)
    move_60m_pct = Column(Float, nullable=True)
    
    outcome_15m = Column(String(20), default="PENDING") # WIN, LOSS, FLAT, PENDING
    outcome_30m = Column(String(20), default="PENDING")
    outcome_60m = Column(String(20), default="PENDING")
    
    status = Column(String(20), default="PENDING", index=True) # PENDING, COMPLETED


class ObservationLog(Base):
    __tablename__ = "observation_logs"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    spot_price = Column(Float)
    market_state = Column(String(30))
    system_signal = Column(String(20)) # BUY_CALL, BUY_PUT, NO_TRADE
    manual_signal = Column(String(20)) # BUY_CALL, BUY_PUT, STAY_OUT, NO_RECORD
    suggested_strike = Column(String(20), nullable=True)
    result_15m = Column(String(20), default="PENDING")
    result_30m = Column(String(20), default="PENDING")
    result_60m = Column(String(20), default="PENDING")
    notes = Column(Text, nullable=True) # JSON details
    manual_decision_id = Column(Integer, ForeignKey("manual_trader_decisions.id", ondelete="SET NULL"), nullable=True)
    system_signal_id = Column(Integer, ForeignKey("trading_signals.id", ondelete="SET NULL"), nullable=True)
    status = Column(String(20), default="PENDING", index=True)


class TradeSession(Base):
    __tablename__ = "trade_sessions"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(String(20), unique=True, index=True)  # YYYY-MM-DD
    capital_allocated = Column(Float, default=0.0)
    pnl = Column(Float, default=0.0)
    emotion_rating = Column(String(20), nullable=True)  # e.g., CALM, GREEDY, ANXIOUS
    stopped_reason = Column(String(50), nullable=True)  # e.g., DAILY_PROFIT_LIMIT, DAILY_LOSS_LIMIT, MANUAL
    daily_limit_hit = Column(Boolean, default=False)
    
    # Advanced risk metrics
    trade_count = Column(Integer, default=0)
    winning_streak = Column(Integer, default=0)
    losing_streak = Column(Integer, default=0)
    max_drawdown_today = Column(Float, default=0.0)
    max_profit_today = Column(Float, default=0.0)
    stopped_automatically = Column(Boolean, default=False)
    
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class MarketRegime(Base):
    __tablename__ = "market_regimes"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    trend = Column(String(20))           # TRENDING, RANGING
    volatility = Column(String(20))      # HIGH, LOW
    session_phase = Column(String(20))   # OPENING, MIDDAY, CLOSING
    regime_confidence = Column(Float, default=0.0)


class DailyReport(Base):
    __tablename__ = "daily_reports"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(String(10), unique=True, index=True)  # YYYY-MM-DD
    summary_json = Column(Text)
    markdown_content = Column(Text)


class DatasetMetadata(Base):
    """Immutable provenance record for one captured research snapshot."""

    __tablename__ = "dataset_metadata"
    __table_args__ = (
        UniqueConstraint(
            "source_table",
            "source_snapshot_id",
            "timeframe",
            "dataset_version",
            name="uq_dataset_metadata_source_version",
        ),
    )

    id = Column(Integer, primary_key=True, index=True)
    captured_at = Column(DateTime, default=datetime.utcnow, index=True)
    market_timestamp = Column(DateTime, index=True)
    symbol = Column(String(20), index=True)
    expiry_date = Column(String(20), index=True)
    timeframe = Column(String(10), index=True)
    source_table = Column(String(50), index=True)
    source_snapshot_id = Column(Integer, index=True)
    provider = Column(String(30))
    provider_version = Column(String(30), default="unversioned")
    api_source = Column(String(50), default="unknown")
    engine_version = Column(String(20), index=True)
    feature_version = Column(String(20), index=True)
    dataset_version = Column(String(20), index=True)
    symbol_version = Column(String(20), default="v1")
    timezone = Column(String(40), default="Asia/Kolkata")
    crawl_latency_ms = Column(Integer, default=0)
    crawl_success = Column(Boolean, default=True, index=True)
    missing_fields = Column(Text, default="[]")
    quality_score = Column(Integer, default=0)


class PatternLibrary(Base):
    """Mutable aggregate statistics for a versioned deterministic pattern."""

    __tablename__ = "pattern_library"
    __table_args__ = (
        UniqueConstraint(
            "symbol",
            "timeframe",
            "pattern_id",
            "pattern_version",
            name="uq_pattern_library_identity",
        ),
    )

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String(20), index=True)
    timeframe = Column(String(10), index=True)
    pattern_id = Column(String(100), index=True)
    pattern_version = Column(String(20), index=True)
    signature_json = Column(Text)
    observed_count = Column(Integer, default=0)
    average_confidence = Column(Float, default=0.0)
    maximum_confidence = Column(Float, default=0.0)
    average_age_snapshots = Column(Float, default=0.0)
    maximum_age_snapshots = Column(Integer, default=0)
    first_seen_at = Column(DateTime, index=True)
    last_seen_at = Column(DateTime, index=True)
    engine_version = Column(String(20), index=True)
    feature_version = Column(String(20), index=True)
    dataset_version = Column(String(20), index=True)


class PatternObservation(Base):
    """Append-only pattern classification for one market snapshot."""

    __tablename__ = "pattern_observations"
    __table_args__ = (
        UniqueConstraint(
            "source_table",
            "source_snapshot_id",
            "timeframe",
            "engine_version",
            name="uq_pattern_observation_source_engine",
        ),
    )

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    expiry_date = Column(String(20), index=True)
    timeframe = Column(String(10), index=True)
    source_table = Column(String(50), index=True)
    source_snapshot_id = Column(Integer, index=True)
    feature_snapshot_id = Column(Integer, ForeignKey("ml_feature_snapshots.id", ondelete="SET NULL"), nullable=True, index=True)
    dataset_metadata_id = Column(Integer, ForeignKey("dataset_metadata.id", ondelete="RESTRICT"), index=True)
    pattern_library_id = Column(Integer, ForeignKey("pattern_library.id", ondelete="RESTRICT"), index=True)
    pattern_id = Column(String(100), index=True)
    pattern_version = Column(String(20), index=True)
    pattern_confidence = Column(Float, default=0.0)
    pattern_age_snapshots = Column(Integer, default=1)
    pattern_started_at = Column(DateTime, index=True)
    trend_state = Column(String(20), index=True)
    oi_state = Column(String(20), index=True)
    pcr_state = Column(String(20), index=True)
    market_state = Column(String(30), nullable=True)
    regime_trend = Column(String(20), nullable=True)
    spot_price = Column(Float)
    ema20 = Column(Float, nullable=True)
    atr = Column(Float, nullable=True)
    total_oi = Column(Integer, default=0)
    oi_change_pct = Column(Float, default=0.0)
    pcr = Column(Float, nullable=True)
    pcr_change = Column(Float, default=0.0)
    data_quality_score = Column(Integer, default=0)
    engine_version = Column(String(20), index=True)
    feature_version = Column(String(20), index=True)
    dataset_version = Column(String(20), index=True)


class FeatureLineage(Base):
    """Append-only explanation of how one derived research feature was produced."""

    __tablename__ = "feature_lineage"
    __table_args__ = (
        UniqueConstraint(
            "pattern_observation_id",
            "feature_name",
            "feature_version",
            name="uq_feature_lineage_observation_feature",
        ),
    )

    id = Column(Integer, primary_key=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    pattern_observation_id = Column(Integer, ForeignKey("pattern_observations.id", ondelete="CASCADE"), index=True)
    feature_name = Column(String(50), index=True)
    feature_version = Column(String(20), index=True)
    source_fields = Column(Text)
    source_values = Column(Text)
    transformation = Column(Text)
    output_value = Column(Text)


class PatternLifecycle(Base):
    """Append-only lifecycle summary for one contiguous pattern sequence."""

    __tablename__ = "pattern_lifecycles"

    id = Column(Integer, primary_key=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    timeframe = Column(String(10), index=True)
    pattern_id = Column(String(100), index=True)
    pattern_version = Column(String(20), index=True)
    pattern_start = Column(DateTime, index=True)
    pattern_end = Column(DateTime, index=True, nullable=True)
    duration_minutes = Column(Float, default=0.0)
    observations = Column(Integer, default=0)
    peak_confidence = Column(Float, default=0.0)
    peak_score = Column(Float, default=0.0)
    average_score = Column(Float, default=0.0)
    average_move = Column(Float, default=0.0)
    largest_move = Column(Float, default=0.0)
    failure_reason = Column(String(100), nullable=True)
    completion_status = Column(String(30), default="OPEN", index=True)
    source_observation_ids = Column(Text, default="[]")
    dataset_version = Column(String(20), index=True)


class PatternTransition(Base):
    """Append-only transition edge between deterministic pattern states."""

    __tablename__ = "pattern_transitions"

    id = Column(Integer, primary_key=True, index=True)
    observed_at = Column(DateTime, default=datetime.utcnow, index=True)
    symbol = Column(String(20), index=True)
    timeframe = Column(String(10), index=True)
    from_pattern_id = Column(String(100), index=True)
    to_pattern_id = Column(String(100), index=True)
    transition_count = Column(Integer, default=1)
    average_minutes = Column(Float, default=0.0)
    pattern_version = Column(String(20), index=True)
    dataset_version = Column(String(20), index=True)


class ExecutionStrikeCandidate(Base):
    """Append-only strike candidate research row captured around a signal."""

    __tablename__ = "execution_strike_candidates"

    id = Column(Integer, primary_key=True, index=True)
    captured_at = Column(DateTime, default=datetime.utcnow, index=True)
    signal_id = Column(Integer, ForeignKey("trading_signals.id", ondelete="SET NULL"), nullable=True, index=True)
    snapshot_id = Column(Integer, index=True)
    symbol = Column(String(20), index=True)
    expiry_date = Column(String(20), index=True)
    option_type = Column(String(5), index=True)
    strike_role = Column(String(10), index=True)
    strike = Column(Float, index=True)
    premium = Column(Float, default=0.0)
    spread = Column(Float, default=0.0)
    iv = Column(Float, default=0.0)
    oi = Column(Integer, default=0)
    volume = Column(Integer, default=0)
    delta = Column(Float, default=0.0)
    gamma = Column(Float, default=0.0)
    theta = Column(Float, default=0.0)
    vega = Column(Float, default=0.0)
    liquidity_score = Column(Float, default=0.0)
    distance_from_spot = Column(Float, default=0.0)
    expected_intrinsic_value = Column(Float, default=0.0)
    expected_time_value = Column(Float, default=0.0)
    feature_version = Column(String(20), index=True)
    dataset_version = Column(String(20), index=True)


class PremiumEvolution(Base):
    """Append-only premium path after a signal or strike candidate."""

    __tablename__ = "premium_evolution"

    id = Column(Integer, primary_key=True, index=True)
    captured_at = Column(DateTime, default=datetime.utcnow, index=True)
    signal_id = Column(Integer, ForeignKey("trading_signals.id", ondelete="SET NULL"), nullable=True, index=True)
    candidate_id = Column(Integer, ForeignKey("execution_strike_candidates.id", ondelete="SET NULL"), nullable=True, index=True)
    horizon_minutes = Column(Integer, index=True)
    premium = Column(Float, default=0.0)
    roi_pct = Column(Float, default=0.0)
    mfe = Column(Float, default=0.0)
    mae = Column(Float, default=0.0)
    drawdown = Column(Float, default=0.0)
    runup = Column(Float, default=0.0)
    dataset_version = Column(String(20), index=True)


class EntryTimingEvaluation(Base):
    """Append-only delayed-entry comparison for a signal."""

    __tablename__ = "entry_timing_evaluations"

    id = Column(Integer, primary_key=True, index=True)
    captured_at = Column(DateTime, default=datetime.utcnow, index=True)
    signal_id = Column(Integer, ForeignKey("trading_signals.id", ondelete="SET NULL"), nullable=True, index=True)
    delay_minutes = Column(Integer, index=True)
    entry_premium = Column(Float, default=0.0)
    outcome_roi_pct = Column(Float, default=0.0)
    mfe = Column(Float, default=0.0)
    mae = Column(Float, default=0.0)
    is_optimal = Column(Boolean, default=False, index=True)
    dataset_version = Column(String(20), index=True)


class ExitTimingEvaluation(Base):
    """Append-only exit comparison for a signal path."""

    __tablename__ = "exit_timing_evaluations"

    id = Column(Integer, primary_key=True, index=True)
    captured_at = Column(DateTime, default=datetime.utcnow, index=True)
    signal_id = Column(Integer, ForeignKey("trading_signals.id", ondelete="SET NULL"), nullable=True, index=True)
    exit_minute = Column(Integer, index=True)
    exit_premium = Column(Float, default=0.0)
    exit_roi_pct = Column(Float, default=0.0)
    exit_type = Column(String(20), index=True)
    maximum_pain = Column(Float, default=0.0)
    profit_peak = Column(Float, default=0.0)
    dataset_version = Column(String(20), index=True)


class RiskEvaluation(Base):
    """Append-only risk dataset for future risk and sizing models."""

    __tablename__ = "risk_evaluations"

    id = Column(Integer, primary_key=True, index=True)
    captured_at = Column(DateTime, default=datetime.utcnow, index=True)
    signal_id = Column(Integer, ForeignKey("trading_signals.id", ondelete="SET NULL"), nullable=True, index=True)
    expected_risk = Column(Float, default=0.0)
    actual_risk = Column(Float, default=0.0)
    reward = Column(Float, default=0.0)
    drawdown = Column(Float, default=0.0)
    recovery_minutes = Column(Integer, default=0)
    dataset_version = Column(String(20), index=True)


class TrainingRegistry(Base):
    """Append-only registry for future reproducible model experiments."""

    __tablename__ = "training_registry"

    id = Column(Integer, primary_key=True, index=True)
    registered_at = Column(DateTime, default=datetime.utcnow, index=True)
    dataset_version = Column(String(20), index=True)
    feature_version = Column(String(20), index=True)
    rows = Column(Integer, default=0)
    labels = Column(Integer, default=0)
    training_date = Column(DateTime, nullable=True, index=True)
    model_name = Column(String(100), index=True)
    metrics_json = Column(Text, default="{}")
    artifacts_json = Column(Text, default="{}")
    feature_list_json = Column(Text, default="[]")
    status = Column(String(20), default="REGISTERED", index=True)


class FeatureStoreDefinition(Base):
    """Versioned definition for engineered features shared by training and replay."""

    __tablename__ = "feature_store_definitions"
    __table_args__ = (
        UniqueConstraint(
            "feature_name",
            "feature_version",
            name="uq_feature_store_definition_version",
        ),
    )

    id = Column(Integer, primary_key=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    feature_name = Column(String(80), index=True)
    feature_version = Column(String(20), index=True)
    source_fields = Column(Text, default="[]")
    transformation = Column(Text)
    leakage_safe = Column(Boolean, default=True, index=True)
    owner = Column(String(50), default="research")
    notes = Column(Text, nullable=True)


class ImmutableSnapshotError(ValueError):
    pass


def _prevent_immutable_update(mapper, connection, target):
    raise ImmutableSnapshotError(
        f"{target.__class__.__name__} rows are append-only and cannot be updated"
    )


for _immutable_model in (
    OptionChainSnapshot,
    OptionChainStrike,
    OptionChainSnapshot5m,
    OptionChainStrike5m,
    OptionChainSnapshot15m,
    OptionChainStrike15m,
    DatasetMetadata,
    PatternObservation,
    FeatureLineage,
    PatternLifecycle,
    PatternTransition,
    ExecutionStrikeCandidate,
    PremiumEvolution,
    EntryTimingEvaluation,
    ExitTimingEvaluation,
    RiskEvaluation,
    TrainingRegistry,
):
    event.listen(_immutable_model, "before_update", _prevent_immutable_update)

